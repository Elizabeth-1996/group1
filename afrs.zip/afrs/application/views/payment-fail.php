
<div class="container">
    <div class="col-md-4"></div>
    <div class="col-md-4">
        <div class="myform-container">
            <div class="logo-container">
                <a href="<?php echo base_url(); ?>">
                    <img src="<?php echo base_url(); ?>vendor/v2/images/logo.png" alt="Rathorji" class="img-responsive" />
                </a>
            </div><br>
            <h1>Payment failed</h1>
            <p><a href="<?php echo base_url() ?>upgrade">Please try again</a></p>
            
            <h3>Having problems?</h3>
            <p>If you donâ€™t know how to proceed please contact to our support team.</p><br>
            <p>
                <a href="<?php echo base_url() ?>contact-us" class="get-start btn" style="width: 100%;">Contact  Now</a>
            </p>
            <div class="clearfix"></div>
        </div>
    </div>
    <div class="col-md-4"></div>
</div>

