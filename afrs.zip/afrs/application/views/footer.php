<footer>Â© <?php echo date('Y'); ?> Rathorji.</footer>

<!--js scripts -->
<script src='https://code.jquery.com/jquery-2.2.4.min.js'></script>
<script src='https://www.google.com/recaptcha/api.js'></script>
<script src='https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js'></script>

</body>
</html>
