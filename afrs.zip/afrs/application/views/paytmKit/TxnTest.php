<?php
header("Pragma: no-cache");
header("Cache-Control: no-cache");
header("Expires: 0");
?>
<!DOCTYPE html>
<html>
    <head>
        <title>Merchant Check Out Page</title>
        <meta name="GENERATOR" content="Evrsoft First Page">
    </head>
    <body>
        <h1>Merchant Check Out Page</h1>
        <pre>
        </pre>
    
    </body>
</html>