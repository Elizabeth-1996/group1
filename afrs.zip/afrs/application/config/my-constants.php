<!-- <?php
//defined('BASEPATH') OR exit('No direct script access allowed'); 	

//$config['my_config_item'] = 'my_config_value';
 //define('myamount', 'my_config_item');

// $this->config->load('your_config');
// $value = $this->config->item(ABCD_MY_CONSTANT);  --> -->